from flask import Flask, render_template, request, send_file, jsonify
import os
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from urllib.parse import urlparse

app = Flask(__name__)
DOWNLOAD_FOLDER = 'downloads'
if not os.path.exists(DOWNLOAD_FOLDER):
    os.makedirs(DOWNLOAD_FOLDER)

def get_driver():
    options = Options()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    # Termux users will need to install 'chromium' via pkg
    return webdriver.Chrome(options=options)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/extract', methods=['POST'])
def extract():
    url = request.json.get('url')
    if not url:
        return jsonify({'error': 'URL is required'}), 400

    driver = get_driver()
    try:
        driver.get(url)
        # Wait for images to load
        time.sleep(5) 
        
        # Google Maps images usually have specific tags or classes
        # This finds high-res photo background images or img tags
        elements = driver.find_elements(By.TAG_NAME, 'img')
        image_urls = []
        
        for el in elements:
            src = el.get_attribute('src')
            if src and 'googleusercontent.com' in src:
                # Get higher resolution version by modifying URL parameters
                high_res = src.split('=')[0] + '=s1600'
                if high_res not in image_urls:
                    image_urls.append(high_res)

        return jsonify({'images': image_urls})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        driver.quit()

if __name__ == '__main__':
    # Run on 0.0.0.0 so it's accessible from other devices in the network
    app.run(host='0.0.0.0', port=5000, debug=True)
