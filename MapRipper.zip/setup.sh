#!/bin/bash
echo "Installing dependencies for Termux..."
pkg update && pkg upgrade -y
pkg install python python-pip chromium termux-api -y

# Install Python requirements
pip install flask selenium requests

echo "------------------------------------------------"
echo "Setup Complete!"
echo "To run the tool: python app.py"
echo "Then open: http://localhost:5000 in your browser"
echo "------------------------------------------------"
